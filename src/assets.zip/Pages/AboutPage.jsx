import NavBar from "../Components/NavBar";
import NewsLetter from "../Components/NewsLetter";
import Footer from '../Components/Footer';
function AboutPage(){
    return(
        <div>
            <NavBar/>
            <NewsLetter/>
            <Footer/>
        </div>
    );
}
export default AboutPage;