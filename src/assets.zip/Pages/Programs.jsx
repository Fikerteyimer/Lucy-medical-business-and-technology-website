import CardGrid from "../Components/CardGrid";
import Footer from "../Components/Footer";
import NavBar from "../Components/NavBar";
import NewsLetter from "../Components/NewsLetter";
import ProgramsCard from "../Components/ProgramsCard";
import Heros from "../Components/Heros";
import { categories, courses } from "../data";
import programs from "../assets/programs.jpg";

function Programs(){
    return(
        <div>
            <NavBar/>
            <Heros  title="Our Programs" children="Explore our programs inf medical,business and technology streams" Image={programs}/>
            <ProgramsCard/>
            <NewsLetter/>
            <Footer/>
        </div>
    );

}
export default Programs;